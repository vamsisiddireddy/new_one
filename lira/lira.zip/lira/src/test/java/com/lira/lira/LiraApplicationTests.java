package com.lira.lira;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LiraApplicationTests {

	@Test
	void contextLoads() {
	}

}
